.. python-msp430-tools documentation master file, created by
   sphinx-quickstart on Thu Jan  6 03:42:07 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

python-msp430-tools documentation
=================================

This page's online home is at: http://packages.python.org/python-msp430-tools/

Package home (PyPI): http://pypi.python.org/pypi/python-msp430-tools

Developement / Project page: https://launchpad.net/python-msp430-tools

Contents:

.. toctree::
    :maxdepth: 2

    overview
    commandline_tools
    target
    utilities
    shell
    assembler
    internals
    license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

